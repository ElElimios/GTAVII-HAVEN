show_message("YOU GOT GTA VII, THE WORLDS IS SAVED.");
game_restart();