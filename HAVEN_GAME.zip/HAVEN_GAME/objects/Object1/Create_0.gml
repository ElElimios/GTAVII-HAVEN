spd = 4;
grv = 0.3;
hspd = 0;
vspd = 0;

salto_min = -6;
salto_max = -13;
carga_actual = 0;
velocidad_carga = 0.3;