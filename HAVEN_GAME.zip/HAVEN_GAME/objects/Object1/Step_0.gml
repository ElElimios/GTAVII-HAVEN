var _right = keyboard_check(ord("D"));
var _left = keyboard_check(ord("A"));
var _jump_held = keyboard_check(ord("W"));         
var _jump_released = keyboard_check_released(ord("W")); 

hspd = (_right - _left) * spd;

if (place_meeting(x, y + 1, obj_pared)) {
    
    
   
    if (_jump_held) {
        carga_actual += velocidad_carga;
        
       
        if (carga_actual > 7) {
            carga_actual = 7;
        }
        
      
    }
    
    
    if (_jump_released) {
        vspd = salto_min - carga_actual; 
        carga_actual = 0; 
    }
} else {
  
    carga_actual = 0; 
    vspd = vspd + grv; 
}

if (place_meeting(x + hspd, y, obj_pared)) {
    while (!place_meeting(x + sign(hspd), y, obj_pared)) {
        x = x + sign(hspd);
    }
    hspd = 0;
}
x = x + hspd;

if (place_meeting(x, y + vspd, obj_pared)) {
    while (!place_meeting(x, y + sign(vspd), obj_pared)) {
        y = y + sign(vspd);
    }
    vspd = 0;
}
y = y + vspd;