spd = 2;             
vspd = 0;            
grv = 0.3;           
rango_vision = 500;  
jump_spd = -7;       