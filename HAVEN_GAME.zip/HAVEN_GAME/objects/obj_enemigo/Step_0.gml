var _hspd = 0; 

if (instance_exists(Object1)) {
    var _dir = sign(Object1.x - x); 
    _hspd = _dir * spd;             
    
    // --- LÓGICA DE SALTO INTELIGENTE ---
    if (place_meeting(x, y + 1, obj_pared)) { // Solo salta si está pisando el suelo
        
        // Condición 1: Hay una pared bloqueando su camino
        var _pared_enfrente = place_meeting(x + (_dir * 16), y, obj_pared);
        
        // Condición 2: Hay un hueco o precipicio enfrente (no hay suelo adelante)
        var _hoyo_enfrente = !place_meeting(x + (_dir * 32), y + 16, obj_pared);
        
        // Condición 3: Estás arriba de él, pero está lo suficientemente cerca (48 píxeles) para que valga la pena saltar
        var _cerca_y_arriba = (abs(Object1.x - x) < 48) and (Object1.y < y - 32);
        
        // Si CUALQUIERA de esas tres cosas pasa, es el momento exacto para saltar
        if (_pared_enfrente or _hoyo_enfrente or _cerca_y_arriba) {
            vspd = jump_spd; 
        }
    }
    
    // --- DAÑO AL JUGADOR ---
    if (place_meeting(x, y, Object1)) {
        show_message("¡El enemigo te ha atrapado!");
        room_restart(); 
    }
}

// 2. Aplicar gravedad
vspd = vspd + grv;

// 3. COLISIÓN HORIZONTAL
if (place_meeting(x + _hspd, y, obj_pared)) {
    while (!place_meeting(x + sign(_hspd), y, obj_pared)) {
        x = x + sign(_hspd);
    }
    _hspd = 0; 
}
x = x + _hspd;

// 4. COLISIÓN VERTICAL 
if (place_meeting(x, y + vspd, obj_pared)) {
    while (!place_meeting(x, y + sign(vspd), obj_pared)) {
        y = y + sign(vspd);
    }
    vspd = 0; 
}
y = y + vspd;